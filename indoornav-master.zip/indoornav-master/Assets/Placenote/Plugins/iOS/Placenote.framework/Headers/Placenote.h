//
//  Placenote.h
//  Placenote
//
//  Created by Brad Hoekstra on 2018-01-17.
//  Copyright © 2018 Yan Ma. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Placenote.
FOUNDATION_EXPORT double PlacenoteVersionNumber;

//! Project version string for Placenote.
FOUNDATION_EXPORT const unsigned char PlacenoteVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Placenote/PublicHeader.h>


